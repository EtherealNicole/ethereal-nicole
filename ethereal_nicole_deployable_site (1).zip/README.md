# Ethereal Nicole

A responsive, nature-inspired static web app for creative projects, learning paths, a planner, a journal, and a demo community feed.

## Run it
Open `index.html` in a modern browser. Most features work without a build step.

## Publish free with GitHub Pages
1. Create/sign in to your own GitHub account at https://github.com.
2. Create a **public** repository named `ethereal-nicole`.
3. Choose **Add file → Upload files** and upload `index.html` from this folder. You may also upload this README.
4. Commit the changes.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose branch `main` and folder `/(root)`, then click **Save**.
8. Wait for deployment. The Pages section will show the published URL.

Official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Important limitations
- This is a static prototype, not a complete multi-user social network.
- Planner, journal, story drafts, art ideas, profile preferences, and sample posts use browser local storage. They stay in that browser/device and are not synchronized across devices.
- Do not store sensitive or highly private information in the prototype journal.
- The community feed is demo content; publishing a post only changes the local browser.
- The music area is a player interface only; it does not stream audio.
- Real sign-in, cloud storage, image uploads, moderation, privacy controls, and cross-device syncing require a backend and additional security work.
- GitHub Pages sites are public on the internet. Do not upload passwords, private journal entries, or personal information to the repository.
